package com.stepway.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.util.Locale

private val Bg = Color(0xFF080C0F)
private val Card = Color(0xFF12181C)
private val Lime = Color(0xFFB8FF24)
private val Muted = Color(0xFF95A0A8)
private val Danger = Color(0xFFFF363D)

enum class WalkState { IDLE, RUNNING, PAUSED, FINISHED }

data class WalkUiState(
    val state: WalkState = WalkState.IDLE,
    val steps: Int = 0,
    val elapsedMs: Long = 0L,
    val sensorAvailable: Boolean = true
)

class MainActivity : ComponentActivity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var stepSensor: Sensor? = null
    private var baseSensorValue: Float? = null
    private var lastSensorValue: Float? = null
    private var walkState by mutableStateOf(WalkUiState())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        walkState = walkState.copy(sensorAvailable = stepSensor != null)
        setContent { StepWayApp() }
    }

    private fun registerSteps() {
        stepSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
    }
    private fun unregisterSteps() = sensorManager.unregisterListener(this)

    override fun onSensorChanged(event: SensorEvent?) {
        val value = event?.values?.firstOrNull() ?: return
        lastSensorValue = value
        if (walkState.state == WalkState.RUNNING) {
            if (baseSensorValue == null) baseSensorValue = value
            val count = (value - (baseSensorValue ?: value)).toInt().coerceAtLeast(0)
            walkState = walkState.copy(steps = count)
        }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    @Composable
    private fun StepWayApp() {
        MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Card, primary = Lime)) {
            var permissionGranted by remember {
                mutableStateOf(Build.VERSION.SDK_INT < 29 || ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED)
            }
            val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
                permissionGranted = granted
                if (granted) registerSteps()
            }
            DisposableEffect(permissionGranted) {
                if (permissionGranted) registerSteps()
                onDispose { unregisterSteps() }
            }
            LaunchedEffect(walkState.state) {
                while (walkState.state == WalkState.RUNNING) {
                    delay(1000)
                    walkState = walkState.copy(elapsedMs = walkState.elapsedMs + 1000)
                }
            }

            Surface(Modifier.fillMaxSize(), color = Bg) {
                when (walkState.state) {
                    WalkState.IDLE -> HomeScreen(walkState) {
                        if (!permissionGranted && Build.VERSION.SDK_INT >= 29) permissionLauncher.launch(Manifest.permission.ACTIVITY_RECOGNITION)
                        else startWalk()
                    }
                    WalkState.RUNNING, WalkState.PAUSED -> ActiveScreen(walkState, ::togglePause, ::finishWalk)
                    WalkState.FINISHED -> SummaryScreen(walkState, ::resetWalk)
                }
            }
        }
    }

    private fun startWalk() {
        baseSensorValue = lastSensorValue
        walkState = WalkUiState(state = WalkState.RUNNING, sensorAvailable = stepSensor != null)
    }
    private fun togglePause() {
        walkState = walkState.copy(state = if (walkState.state == WalkState.RUNNING) WalkState.PAUSED else WalkState.RUNNING)
    }
    private fun finishWalk() { walkState = walkState.copy(state = WalkState.FINISHED) }
    private fun resetWalk() {
        baseSensorValue = lastSensorValue
        walkState = WalkUiState(sensorAvailable = stepSensor != null)
    }
}

@Composable
private fun HomeScreen(s: WalkUiState, onStart: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Menu, null, tint = Color.White)
            Text("StepWay", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Icon(Icons.Default.Settings, null, tint = Color.White)
        }
        CardBlock {
            Text("Привет!", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text("Готов к новой прогулке?", color = Muted)
        }
        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(230.dp).background(Card, CircleShape), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.DirectionsWalk, null, tint = Lime, modifier = Modifier.size(45.dp))
                        Text("0", color = Color.White, fontSize = 72.sp, fontWeight = FontWeight.Bold)
                        Text("шагов", color = Color.White, fontSize = 20.sp)
                    }
                }
                Spacer(Modifier.height(24.dp))
                if (!s.sensorAvailable) Text("На этом устройстве нет датчика шагов", color = Color(0xFFFFB74D), textAlign = TextAlign.Center)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("0.00", "км", "Расстояние", Modifier.weight(1f))
            StatCard("00:00:00", "", "Время", Modifier.weight(1f))
        }
        Button(onClick = onStart, enabled = s.sensorAvailable, modifier = Modifier.fillMaxWidth().height(68.dp), shape = RoundedCornerShape(34.dp), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Color.Black)) {
            Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("НАЧАТЬ ПРОГУЛКУ", fontWeight = FontWeight.Black)
        }
        Text("Карта маршрута будет подключена на следующем этапе", color = Muted, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun ActiveScreen(s: WalkUiState, onPause: () -> Unit, onStop: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Spacer(Modifier.height(16.dp)); Text("Прогулка", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        Text(String.format(Locale.US, "%,d", s.steps).replace(',', ' '), color = Color.White, fontSize = 68.sp, fontWeight = FontWeight.Black)
        Text("шагов", color = Color.White, fontSize = 20.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            MiniStat("${"%.2f".format(Locale.US, s.steps * 0.00075)} км", "Расстояние")
            MiniStat(formatTime(s.elapsedMs), "Время")
            MiniStat("${(s.steps * 0.04).toInt()} ккал", "Примерно")
        }
        Box(Modifier.fillMaxWidth().weight(1f).background(Card, RoundedCornerShape(26.dp)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Map, null, tint = Lime, modifier = Modifier.size(54.dp))
                Spacer(Modifier.height(12.dp)); Text("Карта маршрута", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Text("Google Maps подключим позже", color = Muted)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = onPause, modifier = Modifier.weight(1f).height(64.dp), colors = ButtonDefaults.buttonColors(containerColor = Card), shape = RoundedCornerShape(28.dp)) {
                Icon(if (s.state == WalkState.RUNNING) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                Spacer(Modifier.width(6.dp)); Text(if (s.state == WalkState.RUNNING) "ПАУЗА" else "ПРОДОЛЖИТЬ")
            }
            Button(onClick = onStop, modifier = Modifier.weight(1f).height(64.dp), colors = ButtonDefaults.buttonColors(containerColor = Danger), shape = RoundedCornerShape(28.dp)) {
                Icon(Icons.Default.Stop, null); Spacer(Modifier.width(6.dp)); Text("СТОП", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SummaryScreen(s: WalkUiState, onNew: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Spacer(Modifier.height(30.dp)); Icon(Icons.Default.EmojiEvents, null, tint = Lime, modifier = Modifier.size(70.dp))
        Text("Прогулка завершена", color = Color.White, fontWeight = FontWeight.Black, fontSize = 28.sp)
        Text("Отличная работа!", color = Muted, fontSize = 18.sp)
        CardBlock {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { MiniStat("${s.steps}", "Шаги"); MiniStat("${"%.2f".format(Locale.US, s.steps * 0.00075)} км", "Расстояние") }
            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { MiniStat(formatTime(s.elapsedMs), "Время"); MiniStat("${(s.steps * 0.04).toInt()} ккал", "Примерно") }
        }
        Spacer(Modifier.weight(1f))
        Button(onClick = onNew, modifier = Modifier.fillMaxWidth().height(66.dp), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Color.Black), shape = RoundedCornerShape(32.dp)) {
            Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(8.dp)); Text("НОВАЯ ПРОГУЛКА", fontWeight = FontWeight.Black)
        }
    }
}

@Composable private fun CardBlock(content: @Composable ColumnScope.() -> Unit) = Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), content = content) }
@Composable private fun StatCard(value: String, unit: String, label: String, modifier: Modifier = Modifier) = Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(22.dp), modifier = modifier) { Column(Modifier.padding(18.dp)) { Text(value, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold); if (unit.isNotBlank()) Text(unit, color = Color.White); Text(label, color = Muted, fontSize = 13.sp) } }
@Composable private fun MiniStat(value: String, label: String) = Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(label, color = Muted, fontSize = 12.sp) }
private fun formatTime(ms: Long): String { val t = ms / 1000; return "%02d:%02d:%02d".format(t / 3600, (t % 3600) / 60, t % 60) }
